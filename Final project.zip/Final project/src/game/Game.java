package game;

import java.io.File;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.Parent;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;

public class Game extends Application{
	boolean exist = false;
	@Override
	public void start(Stage s)throws Exception{
		Parent root = FXMLLoader.load(getClass().getResource("/game/Scene1.fxml")); //Parent:�D����
		
		Scene scene = new Scene(root);
		s.setScene(scene);
		Image application = new Image("/game/box48p.png");
		s.getIcons().add(application);
		s.setTitle("SOKOBAN");
		s.setResizable(false);
		s.show();
		File f = new File("data.save");
		if(f.exists() && !f.isDirectory()) {    
			
		}
		else {
			Save_Data sd = new Save_Data();
			resourceManager.save(sd);
		}
	}
	public static void main(String[] args) {
		launch();
	}
	
}

package game;

import java.io.*;
import java.util.*;
import javafx.animation.PathTransition;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.stage.Stage;
import javafx.util.Duration;

class Save{
	
}
public class Record implements Serializable{
	Stage stage = new Stage();
	public Record() {
	}
	public Record(Stage s){
		stage = s;
		stage.setResizable(false);
		try {
			final AnchorPane ap = FXMLLoader.load(getClass().getResource("/game/Game_Record.fxml"));
			Scene scene = new Scene(ap);
			stage.setScene(scene);
			final Rectangle rect = new Rectangle(1200,700);        //(x,y,�e,��)
			rect.setFill(Color.BLACK);
			
			Line line = new Line();
		    line.setStartX(200);
		    line.setStartY(350);
			line.setEndX(-700);
			line.setEndY(350);
			
			PathTransition pt = new PathTransition();
			pt.setDuration(Duration.seconds(2.0));
			pt.setPath(line);
			pt.setNode(rect);
			pt.play();
			
			ap.getChildren().add(rect);
			
			Button back = (Button)scene.lookup("#back");
			Button reset = (Button)scene.lookup("#reset");
			back.setOnMouseClicked(new EventHandler<MouseEvent>() {
				@Override
				public void handle(MouseEvent event) {
					final Rectangle rect = new Rectangle(1200,700);        //(x,y,�e,��)
					rect.setFill(Color.BLACK);
					
					Line line = new Line();
					line.setStartX(1300);
					line.setStartY(350);
					line.setEndX(-700);
					line.setEndY(350);
					
					PathTransition pt = new PathTransition();
					pt.setDuration(Duration.seconds(2.75));
					pt.setPath(line);
					pt.setNode(rect);
					pt.play();
					
					ap.getChildren().add(rect);
					TimerTask tt = new TimerTask() {
						public void run() {
							Platform.runLater(new Runnable() {        
								public void run() {
									try {
										StackPane sp = FXMLLoader.load(getClass().getResource("/game/Scene1.fxml"));
										Scene scene = new Scene(sp);
										stage.setScene(scene);
									} catch (IOException ex) {
										// TODO Auto-generated catch block
										ex.printStackTrace();
									}
								}
							});
						}
					};
					new Timer().schedule(tt,1200);
				}
			});
			reset.setOnMouseClicked(new EventHandler<MouseEvent>() {
				@Override
				public void handle(MouseEvent event) {
					final Rectangle rect = new Rectangle(1200,700);        //(x,y,�e,��)
					rect.setFill(Color.BLACK);
					
					Line line = new Line();
					line.setStartX(1300);
					line.setStartY(350);
					line.setEndX(-700);
					line.setEndY(350);
					
					PathTransition pt = new PathTransition();
					pt.setDuration(Duration.seconds(2.75));
					pt.setPath(line);
					pt.setNode(rect);
					pt.play();
					
					ap.getChildren().add(rect);
					TimerTask tt = new TimerTask() {
						public void run() {
							Platform.runLater(new Runnable() {        
								public void run() {
									try {
										Save_Data sd = new Save_Data();
										sd.time1=0;
										sd.time2=0;
										sd.time3=0;
										sd.time4=0;
										sd.time5=0;
										sd.step1=0;
										sd.step2=0;
										sd.step3=0;
										sd.step4=0;
										sd.step5=0;
										try {
											resourceManager.save(sd);
											new Record(stage);
										}catch(Exception e) {
											e.printStackTrace();
										}
									} catch(Exception e) {
										e.printStackTrace();
									}
								}
							});
						}
					};
					new Timer().schedule(tt,1200);
				}
			});
			GridPane gp = (GridPane)scene.lookup("#gridpane");
			Show(scene,gp);
		}
		catch(IOException e){
			e.printStackTrace();
		}
	}
	private void Show(Scene scene,GridPane gp) {
		try {                               //Ū��
			Save_Data data = (Save_Data)resourceManager.load();
			Label time1 = (Label)scene.lookup("#time1");
			Label time2 = (Label)scene.lookup("#time2");
			Label time3 = (Label)scene.lookup("#time3");
			Label time4 = (Label)scene.lookup("#time4");
			Label time5 = (Label)scene.lookup("#time5");
			Label step1 = (Label)scene.lookup("#step1");
			Label step2 = (Label)scene.lookup("#step2");
			Label step3 = (Label)scene.lookup("#step3");
			Label step4 = (Label)scene.lookup("#step4");
			Label step5 = (Label)scene.lookup("#step5");
			
			time1.setText(""+String.format(" %02d:%02d:%02d", data.time1/3600, data.time1/60, data.time1%60));
			time2.setText(""+String.format(" %02d:%02d:%02d", data.time2/3600, data.time2/60, data.time2%60));
			time3.setText(""+String.format(" %02d:%02d:%02d", data.time3/3600, data.time3/60, data.time3%60));
			time4.setText(""+String.format(" %02d:%02d:%02d", data.time4/3600, data.time4/60, data.time4%60));
			time5.setText(""+String.format(" %02d:%02d:%02d", data.time5/3600, data.time5/60, data.time5%60));
			step1.setText(""+data.step1);
			step2.setText(""+data.step2);
			step3.setText(""+data.step3);
			step4.setText(""+data.step4);
			step5.setText(""+data.step5);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	boolean first = true;
	public void overwrite(int level,int time,int step) {
		Save_Data sd = new Save_Data();
		File f = new File("data.save");
		if(f.exists() && !f.isDirectory()) {    //�p�G�ɮצs�b
			try {                               //�л\�ɮ�
				Save_Data data = (Save_Data)resourceManager.load();
				step++;	
				sd.time1=data.time1;
				sd.step1=data.step1;
							
				sd.time2=data.time2;
				sd.step2=data.step2;
							
				sd.time3=data.time3;
				sd.step3=data.step3;
							
				sd.time4=data.time4;
				sd.step4=data.step4;
				
				sd.time5=data.time5;
				sd.step5=data.step5;
				
				switch(level) {
				 case 0:
					 if(time<sd.time1||sd.time1==0)
						 sd.time1=time;
					 if(step<sd.step1||sd.step1==0)
						 sd.step1=step;
					 break;
				 case 1:
					 if(time<sd.time2||sd.time2==0)
						 sd.time2=time;
					 if(step<sd.step2||sd.step2==0)
						 sd.step2=step;
					 break;
				 case 2:
					 if(time<sd.time3||sd.time3==0)
						 sd.time3=time;
					 if(step<sd.step3||sd.step3==0)
						 sd.step3=step;
					 break;
				 case 3:
					 if(time<sd.time4||sd.time4==0)
						 sd.time4=time;
					 if(step<sd.step4||sd.step4==0)
						 sd.step4=step;
					 break;
				 case 4:
					 if(time<sd.time5||sd.time5==0)
						 sd.time5=time;
					 if(step<sd.step5||sd.step5==0)
						 sd.step5=step;
					 break;
					 
				}
				resourceManager.save(sd);
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
	}
}


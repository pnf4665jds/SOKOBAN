package game;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

import javafx.animation.PathTransition;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Scene1_Controller implements Initializable{
	@FXML
	private StackPane rootPane;       //Scene builder���ϥΪ�����ID   (fx:id)
	
	@FXML
	private void handleMouseClick(MouseEvent e) {
		SceneTransitionIn();
		TimerTask tt = new TimerTask() {
    		public void run() {
    			Platform.runLater(new Runnable() {        
    				public void run() {
    					loadNextScene();
    				}
    			});
    		}
    	};
    	new Timer().schedule(tt,1200);
	}
	
	@FXML
	private void OpenRecordScene(MouseEvent e) {
		SceneTransitionIn();
		TimerTask tt = new TimerTask() {
    		public void run() {
    			Platform.runLater(new Runnable() {        
    				public void run() {
    					Stage currentStage = (Stage)rootPane.getScene().getWindow();
    					new Record(currentStage);
    				}
    			});
    		}
    	};
    	new Timer().schedule(tt,1200);
	}
	static boolean first=true;        //�O�_�Ĥ@���i�J�D�e��
	@Override
	public void initialize(URL location, ResourceBundle resource) {         //�}�l�����ɪ���l�ưʧ@
		if(first==false)
			SceneTransitionOut();
		first=false;

	}
/*	private void makeFadeOut() {
		FadeTransition ft = new FadeTransition(Duration.seconds(2),rootPane);
		ft.setFromValue(1);     //���z��1 >>> �z��0
		ft.setToValue(0);
		ft.setOnFinished(new EventHandler<ActionEvent>() {   //���ݰ��浲��
			@Override
			public void handle(ActionEvent event) {
				loadNextScene();
			}
		});
		ft.play();
	}*/
	private void loadNextScene() {
		try {
			StackPane sp = FXMLLoader.load(getClass().getResource("/game/Scene2.fxml"));
			rootPane.getChildren().add(sp);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void SceneTransitionIn() {
		final Rectangle rect = new Rectangle(1200,700);        //(x,y,�e,��)
		rect.setFill(Color.BLACK);
		
		Line line = new Line();
	    line.setStartX(1600);
	    line.setStartY(350);
		line.setEndX(-400);
		line.setEndY(350);
		
		PathTransition pt = new PathTransition();
		pt.setDuration(Duration.seconds(2.75));
		pt.setPath(line);
		pt.setNode(rect);
		pt.play();
		
		rootPane.getChildren().add(rect);
		
	}
	private void SceneTransitionOut() {
		final Rectangle rect = new Rectangle(1200,700);        //(x,y,�e,��)
		rect.setFill(Color.BLACK);
		
		Line line = new Line();
	    line.setStartX(500);
	    line.setStartY(350);
		line.setEndX(-400);
		line.setEndY(350);
		
		PathTransition pt = new PathTransition();
		pt.setDuration(Duration.seconds(2.0));
		pt.setPath(line);
		pt.setNode(rect);
		pt.play();
		
		rootPane.getChildren().add(rect);
	}
	
}

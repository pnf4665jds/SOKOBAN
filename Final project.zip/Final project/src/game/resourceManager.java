package game;

import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Paths;

public class resourceManager {
	public static void save(Serializable data) throws Exception{
		try (ObjectOutputStream oos = new ObjectOutputStream(Files.newOutputStream(Paths.get("data.save")))){
			oos.writeObject(data);
			oos.close();
		}
	}
	public static Object load() throws Exception{
		try (ObjectInputStream ois = new ObjectInputStream(Files.newInputStream(Paths.get("data.save")))){
			return ois.readObject();
		}
	}
}

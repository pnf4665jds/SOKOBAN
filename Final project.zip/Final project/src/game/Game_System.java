package game;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import javafx.animation.Animation;
import javafx.animation.FadeTransition;
import javafx.animation.PathTransition;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.event.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.input.*;
import javafx.scene.layout.*;
import javafx.scene.media.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Game_System {
	private String[] imgbox = new String[]{
			"/game/char48p.png",  //�T�w48pixel
			"/game/box48p.png",
			"/game/floor48p.png",
			"/game/wall48p.png",
			"/game/target48p.png",
			"/game/bomb.png",
			"/game/target_char48p.png"
	};
	MapData map = new MapData();                       //�s�����d��ƪ�class
    static int level;                                  //������d
	private int[][][] map1 =map.getData_Map();         //�����dŪ�����ϥΪ�array  �ݥ�����data�_�h�|�X�{NullPointerException��error
	private Image img ;         
	int anglespeed = 200;
	Animation move_left,move_right,move_up,move_down;			//���Ⲿ�ʰʵe
	Animation char_stop_left,char_stop_right,char_stop_up,char_stop_down; //���ⰱ��ʵe
	static String state ;     //���⪬�A
	
	static ArrayList <ImageView> imv = new ArrayList<ImageView>();     //imageView with ArrayList
	Pane pane=new Pane();        //���O
	Parent root = pane;  
	public Game_System() {
		
	}
	public Game_System(Stage s)
    { 
		Scene scene = new Scene(root,720,650);    //�]�m�����j�p
		s.setTitle("SOKOBAN");                    //���ε{���W��
		s.setScene(scene);                        //�]�m��������Stage
		Image application = new Image(imgbox[1]); //�]�m����Icon
		s.getIcons().add(application);
		s.setResizable(false);                    //������j������
		s.show();                                 //���Stage
		
		pane.setStyle("-fx-background-color: #f4a460");
		Scene2_Controller sc = new Scene2_Controller();
		level=sc.level;                           //�ثe���d
		imv.clear();                              //�CLoad�s���d�N�M�Ŧa��imageview
		getMapData();                             //���o���d���
		BackgroundInitialize();                   //���ͦa��
		CharacterInitialize();                    //���ͨ���
		BoxInitialize();                          //���ͽc�l
		if(level>3)
			bomb_open=true;                           //���u�\��}��
		else {
			bomb_open=false;
		}
		
		state = "DOWN";
		bomb_x=-1;                                
		bomb_y=-1;
		
		move_down = new SpriteAnimation(imv_char,Duration.millis(500),3,3,0,0,48,48);      //�H�����ʰʵe
		move_left = new SpriteAnimation(imv_char,Duration.millis(500),3,3,0,48,48,48);
		move_right = new SpriteAnimation(imv_char,Duration.millis(500),3,3,0,96,48,48);
		move_up = new SpriteAnimation(imv_char,Duration.millis(500),3,3,0,144,48,48);
		char_stop_down = new SpriteAnimation(imv_char,Duration.millis(500),1,1,48,0,48,48);
		char_stop_left = new SpriteAnimation(imv_char,Duration.millis(500),1,1,48,48,48,48);
		char_stop_right = new SpriteAnimation(imv_char,Duration.millis(500),1,1,48,96,48,48);
		char_stop_up = new SpriteAnimation(imv_char,Duration.millis(500),1,1,48,144,48,48);

		char_stop_down.play();
		
		scene.setOnKeyPressed(new EventHandler<KeyEvent>() {        //��V�䲾��
			@Override
			public void handle(KeyEvent e) {
			if(clear==true)	{
			}
			else if(e.getCode()==KeyCode.UP) {
            		char_y-=1;
            		state="UP";     //�H�����¤�V
            		if(map1[level][char_y][char_x]==3&&((char_x!=bomb_x)||(char_y!=bomb_y))) {
            			char_y+=1;
            		}
            		push("up");
            		Animation_Stop();
            		move_up.play();
            		move_up.setOnFinished(new EventHandler<ActionEvent>() {
						
						@Override
						public void handle(ActionEvent arg0) {
							// TODO Auto-generated method stub
							char_stop_up.play();
						}
					});
            	
            }
			else if(e.getCode()==KeyCode.DOWN) {
            		char_y+=1;
            		state="DOWN";
               		if(map1[level][char_y][char_x]==3&&((char_x!=bomb_x)||(char_y!=bomb_y))) {
            			char_y-=1;
               		}
            		push("down");
            		Animation_Stop();
            		move_down.play();
            		move_down.setOnFinished(new EventHandler<ActionEvent>() {
						
						@Override
						public void handle(ActionEvent arg0) {
							// TODO Auto-generated method stub
							char_stop_down.play();
						}
					});
            	
            }
			else if(e.getCode()==KeyCode.LEFT) {
            		char_x-=1;
            		state="LEFT";
               		if(map1[level][char_y][char_x]==3&&((char_x!=bomb_x)||(char_y!=bomb_y))) {
               			char_x+=1;
               		}
            		push("left");
            		Animation_Stop();
            		move_left.play();
            		
            		move_left.setOnFinished(new EventHandler<ActionEvent>() {
						
						@Override
						public void handle(ActionEvent arg0) {
							// TODO Auto-generated method stub
							char_stop_left.play();
						}
					});
            		
            }
			else if(e.getCode()==KeyCode.RIGHT) {
            		char_x+=1;
            		state="RIGHT";
               		if(map1[level][char_y][char_x]==3&&((char_x!=bomb_x)||(char_y!=bomb_y))) {
            			char_x-=1;
               		}
            		push("right");
            		Animation_Stop();
            		move_right.play();
            	
            		move_right.setOnFinished(new EventHandler<ActionEvent>() {
						
						@Override
						public void handle(ActionEvent arg0) {
							// TODO Auto-generated method stub
							char_stop_right.play();
						}
					});
            		
            }
    		imv_char.setLayoutX(char_x*48);
    		imv_char.setLayoutY(char_y*48);
    		Step();
			}
			
		});
		Button_restart();
		Button_back();
		Button_help();
		Button_level();
		Button_bgm();
		Button_se();
		
		Step();                         //�p�B
		Time();                         //�p��
		Level();                        //�������
		record();                       //�������e������
		music_bgm();     
		Bomb();                         //���u�\��
		
    	pane.getChildren().add(step_label);       //�[�Jstep_label
		pane.getChildren().add(imv_char);         //�[�Jimv_char
    	pane.getChildren().add(time_label);
    	pane.getChildren().add(level_label);
		pane.requestFocus();
		
		SceneTransitionOut();
		
    }
	
	private void Animation_Stop() {     //���ʮɱj������L�ʵe����H�����H�M�P
		move_right.stop();
		move_left.stop();
		move_down.stop();
		move_up.stop();
		char_stop_right.stop();
		char_stop_left.stop();
		char_stop_down.stop();
		char_stop_up.stop();
	}
	private void SceneTransitionOut() {
		final Rectangle rect = new Rectangle(1200,700);        //(x,y,�e,��)
		rect.setFill(Color.BLACK);
		
		Line line = new Line();
	    line.setStartX(500);
	    line.setStartY(350);
		line.setEndX(-600);
		line.setEndY(350);
		
		PathTransition pt = new PathTransition();
		pt.setDuration(Duration.seconds(2.0));
		pt.setPath(line);
		pt.setNode(rect);
		pt.play();
		
		pane.getChildren().add(rect);
	}

	static int char_x, char_y;   //�����m
	int box_x[] ;	      //�c�l��m
	int box_y[] ;
    
	public void getMapData() {
		level=Scene2_Controller.level;
	    box_x = new int[map.box_data_x[level].length] ;	      //�c�l��m
	    box_y = new int[map.box_data_y[level].length] ;
		for(int i=0; i<12; i++){
			for(int j=0; j<12; j++) {
				map1[level][i][j]=map.getData_Map()[level][i][j];
			}
		}
		for(int i=0;i<map.getData_Box_x()[level].length;i++) {
			box_x[i]=map.getData_Box_x()[level][i];
			box_y[i]=map.getData_Box_y()[level][i];
		}
	}
	public void BackgroundInitialize() {
		for(int i=0 ;i<12 ;i++) {
			for(int j=0 ; j<12 ;j++)
			{
				if(map.getData_Map()[level][i][j]==2) {
				    img = new Image(imgbox[2]);
				}
				else if(map.getData_Map()[level][i][j]==3)
					img = new Image(imgbox[3]);
				else if(map.getData_Map()[level][i][j]==4)
					img = new Image(imgbox[4]);
				
				ImageView iv= new ImageView();
				iv.setImage(img);
				iv.setLayoutX(j*48);
				iv.setLayoutY(i*48);
				imv.add(iv);
			}
		}
		pane.getChildren().addAll(imv);        //�ϥ�arraylist�~��N�C��image�L�X
	
		char_record = new ArrayList<>();
		box_record = new ArrayList<Integer>();
	}
	
	Image img_char = new Image("/game/move_character.png");
	ImageView imv_char = new ImageView();
	
	public void CharacterInitialize() {
		char_x=map.char_data_x[level];
		char_y=map.char_data_y[level];
		imv_char.setImage(img_char);
		imv_char.setLayoutX(char_x*48);
		imv_char.setLayoutY(char_y*48);		
		
		
	}
	Image image_box = new Image(imgbox[1]);
	ArrayList<ImageView> box_imv = new ArrayList<ImageView>();
	public void BoxInitialize() {
			pane.getChildren().removeAll(box_imv);   //�M����c�l
			box_imv.removeAll(box_imv);              //�M��ArrayList
		for(int i=0;i<map.box_data_x[level].length;i++) {
			box_x[i]=map.getData_Box_x()[level][i];
			box_y[i]=map.getData_Box_y()[level][i];
			ImageView box_iv= new ImageView();
			box_iv.setImage(image_box);
			box_iv.setLayoutX(box_x[i]*48+8);        //��m�ݥ[8   ��]����
			box_iv.setLayoutY(box_y[i]*48+8);
			box_imv.add(box_iv);
		}
			pane.getChildren().addAll(box_imv);
	}
	
    int target=0;                                   //���b�Q�����c�l�s��
    public void push(String direct) {               //push box
        boolean touch = false;                      //�O�_��Ĳ�I�c�l
        if(se_on==true)
        	music_se("Move");                           //���񲾰ʭ���
    	for(int i=0; i<box_x.length;i++) {
    		if((char_x==box_x[i])&&(char_y==box_y[i])) {
    			target=i;
    			touch = true;
    		}
    	}
    		if(touch == true) {
    			if(direct=="up") {
    				box_y[target]-=1;
    				for(int k=0; k<box_x.length;k++){
    					if(k==target)
    						continue;
    					else if((box_x[k]==char_x)&&(box_y[k]==char_y-1)){
    						char_y+=1;
    						box_y[target]+=1;
    						break;
    					}
    				}
    				if(map1[level][box_y[target]][box_x[target]]==3&&((box_x[target]!=bomb_x)||(box_y[target]!=bomb_y))) {//�I�����
    					char_y+=1;
    					box_y[target]+=1;
    				}
    			}
    			if(direct=="down") {
    				box_y[target]+=1;
    				for(int k=0; k<box_x.length;k++){
    					if(k==target)
    						continue;
    					else if((box_x[k]==char_x)&&(box_y[k]==char_y+1)){
    						char_y-=1;
    						box_y[target]-=1;
    						break;
    					}
    				}
    				if(map1[level][box_y[target]][box_x[target]]==3&&((box_x[target]!=bomb_x)||(box_y[target]!=bomb_y))) {
    					char_y-=1;
    					box_y[target]-=1;
    				}
    			}
    			if(direct=="left") {
    				box_x[target]-=1;
    				for(int k=0; k<box_x.length;k++){
    					if(k==target)
    						continue;
    					else if((box_x[k]==char_x-1)&&(box_y[k]==char_y)){
    						char_x+=1;
    						box_x[target]+=1;
    						break;
    					}
    				}
    				if(map1[level][box_y[target]][box_x[target]]==3&&((box_x[target]!=bomb_x)||(box_y[target]!=bomb_y))) {
    					char_x+=1;
    					box_x[target]+=1;
    				}
    			}
    			if(direct=="right") {
    				box_x[target]+=1;
    				for(int k=0; k<box_x.length;k++){
    					if(k==target)
    						continue;
    					else if((box_x[k]==char_x+1)&&(box_y[k]==char_y)){
    						char_x-=1;
    						box_x[target]-=1;
    						break;
    					}
    				}
    				if(map1[level][box_y[target]][box_x[target]]==3&&((box_x[target]!=bomb_x)||(box_y[target]!=bomb_y))) {
    					char_x-=1;
    					box_x[target]-=1;
    				}
    			}
    			box_imv.get(target).setImage(image_box);
    			box_imv.get(target).setLayoutX(box_x[target]*48+8);        //��m�ݥ[8   ��]����
    			box_imv.get(target).setLayoutY(box_y[target]*48+8);
        		pane.getChildren().removeAll(box_imv);
        		pane.getChildren().addAll(box_imv);
        		goal();            //�P�w�c�l�O�_������w�a�I
    		}
    	
    }
	boolean clear=false;
	Record record = new Record();
    public void goal() {
		int finish=0;               //�������c�l�ƶq
    	for(int i=0;i<box_x.length;i++) {
    		if(map1[level][box_y[i]][box_x[i]]==4) 
    			finish++;
    	}
    	if(finish==box_x.length) {  //�P�_�O�_���Ʊ���
    		clear=true;
    		mediaplayer_BGM.stop();
    		if(se_on==true)
    			music_se("Clear");      //����q������
			makeFadeOut();
			record.overwrite(Scene2_Controller.level,second,step);         //�л\�q������
    	}
    }
    private void makeFadeOut() {
		FadeTransition ft = new FadeTransition(Duration.seconds(2),pane);
		ft.setFromValue(1);     //���z��1 >>> �z��0
		ft.setToValue(0);
		ft.setOnFinished(new EventHandler<ActionEvent>() {   //���ݰ��浲��
			@Override
			public void handle(ActionEvent event) {
				Stage currentStage = (Stage)pane.getScene().getWindow();   //���o�ثe��stage
				new Clear(currentStage);       //�}��Clear�e��
			}
		});
		ft.play();
	}
    public void Button_restart(){
    	Button reset = new Button("  Restart  ");
    	reset.setLayoutX(600);
    	reset.setLayoutY(30);
    	reset.setOnAction(new EventHandler<ActionEvent>() {
    		@Override
    		public void handle(ActionEvent e) {
    			CharacterInitialize();
    			BoxInitialize();
    			if(bomb_x!=-1)
    				Destroyed_Object_Recover();
    			bomb_open=true;
    			bomb_x=-1;
    			bomb_y=-1;
    			if(level>3)
    				bomb_imv.setOpacity(1);
    			step=0;
    			second=0;
    			step_label.setText("�B��:"+step);
    			time_label.setText("�ثe�ɶ�: "+String.format(" %02d:%02d:%02d", second/3600, second/60, second%60));
    			if(se_on==true)
    				music_se("Click");    //�����I������
    			pane.requestFocus();
    		}
    	});
    	reset.setStyle("-fx-background-color: " + 
    			"        linear-gradient(#f2f2f2, #d6d6d6)," + 
    			"        linear-gradient(#fcfcfc 0%, #d9d9d9 20%, #d6d6d6 100%)," + 
    			"        linear-gradient(#dddddd 0%, #f6f6f6 50%);" + 
    			"    -fx-font-size: 16px;"+
    			"    -fx-background-radius: 8,7,6;" + 
    			"    -fx-background-insets: 0,1,2;" + 
    			"    -fx-text-fill: black;" + 
    			"    -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
    	pane.getChildren().add(reset);
	}
    public void Button_back() {
    	Button back = new Button("    Back     ");
    	back.setLayoutX(600);
    	back.setLayoutY(100);
        back.setOnAction(new EventHandler<ActionEvent>() {
        	@Override
        	public void handle(ActionEvent e) {
        		if(step>0)
        			back();
        		if(se_on==true)
        			music_se("Click");
        		pane.requestFocus();
        	}
        });
        back.setStyle("-fx-background-color: " + 
    			"        linear-gradient(#f2f2f2, #d6d6d6)," + 
    			"        linear-gradient(#fcfcfc 0%, #d9d9d9 20%, #d6d6d6 100%)," + 
    			"        linear-gradient(#dddddd 0%, #f6f6f6 50%);" + 
    			"    -fx-font-size: 16px;"+
    			"    -fx-background-radius: 8,7,6;" + 
    			"    -fx-background-insets: 0,1,2;" + 
    			"    -fx-text-fill: black;" + 
    			"    -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
        pane.getChildren().add(back);
    }
    public void Button_help() {
    	Button help = new Button("    Help    ");
    	help.setLayoutX(600);
    	help.setLayoutY(170);
        help.setOnAction(new EventHandler<ActionEvent>() {
        	@Override
        	public void handle(ActionEvent e) {
        		new Help(se_on);
        		if(se_on==true)
        			music_se("Click");
        		pane.requestFocus();
        	}
        });
        help.setStyle("-fx-background-color: " + 
    			"        linear-gradient(#f2f2f2, #d6d6d6)," + 
    			"        linear-gradient(#fcfcfc 0%, #d9d9d9 20%, #d6d6d6 100%)," + 
    			"        linear-gradient(#dddddd 0%, #f6f6f6 50%);" + 
    			"    -fx-font-size: 16px;"+
    			"    -fx-background-radius: 8,7,6;" + 
    			"    -fx-background-insets: 0,1,2;" + 
    			"    -fx-text-fill: black;" + 
    			"    -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
        pane.getChildren().add(help);
    }
    boolean turn_to_level=false;
    
    public void Button_level() {                //�����d
    	Button level = new Button("    Level    ");
    	level.setLayoutX(600);
    	level.setLayoutY(240);
    	level.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				turn_to_level=true;
				if(se_on==true)
					music_se("Click");
				mediaplayer_BGM.stop();
				loadLevelScene();
			}
    	});
    	level.setStyle("-fx-background-color: " + 
    			"        linear-gradient(#f2f2f2, #d6d6d6)," + 
    			"        linear-gradient(#fcfcfc 0%, #d9d9d9 20%, #d6d6d6 100%)," + 
    			"        linear-gradient(#dddddd 0%, #f6f6f6 50%);" + 
    			"    -fx-font-size: 16px;"+
    			"    -fx-background-radius: 8,7,6;" + 
    			"    -fx-background-insets: 0,1,2;" + 
    			"    -fx-text-fill: black;" + 
    			"    -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
    	pane.getChildren().add(level);
    }
    Parent secondView;
    public void loadLevelScene() {             //Ū�������e��
		
		
		final Rectangle rect = new Rectangle(1200,700);        //(x,y,�e,��)
		rect.setFill(Color.BLACK);
		
		Line line = new Line();
	    line.setStartX(1300);
	    line.setStartY(350);
		line.setEndX(-700);
		line.setEndY(350);
		
		PathTransition pt = new PathTransition();
		pt.setDuration(Duration.seconds(2.75));
		pt.setPath(line);
		pt.setNode(rect);
		pt.play();
		
		pane.getChildren().add(rect);
		
		TimerTask tt = new TimerTask() {
    		public void run() {
    			Platform.runLater(new Runnable() {        
    				public void run() {
    					try {
    						secondView = (StackPane)FXMLLoader.load(getClass().getResource("Scene2.fxml"));
    						Scene newScene = new Scene(secondView,720,650);	
    						
    						Stage currentStage = (Stage)pane.getScene().getWindow();
    						currentStage.setScene(newScene);
    						}
    					catch(IOException e) {
    						e.printStackTrace();
    					}
    				}
    			});
    		}
    	};
    	new Timer().schedule(tt,1200);
	}

    boolean bgm_on=true;      				  //�O�_�}��BGM
    boolean bgm_first=true;                   //�O�_�Ĥ@������BGM
    
    Stage stage = new Stage();
	Parent root1;
	AnchorPane ap;
	Label volume_label;
	Slider slider;
	Button bt;
	ChoiceBox<String> cb;
	static double volume = 100.0;
	
    public void Button_bgm() {                //����BGM
    	final Button bgm = new Button("    BGM    ");   	
    	bgm.setLayoutX(600);
    	bgm.setLayoutY(310);
    	mediaplayer_BGM.setVolume(volume/100);    //�]�m���W���վ㪺���q
    	bgm.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				if(se_on==true)
					music_se("Click");
				pane.requestFocus();
					try {
						root1 = FXMLLoader.load(getClass().getResource("BGM_setting.fxml"));
						Scene scene = new Scene(root1);
						stage.setScene(scene);
						stage.setTitle("SOKOBAN");
						Image application = new Image(imgbox[1]);
						stage.getIcons().add(application);
						stage.show();
						
						slider =(Slider)scene.lookup("#volume");       //���q�վ�
						volume_label = (Label)scene.lookup("#volume_label");
						ap = (AnchorPane)scene.lookup("#anchorpane");
						
						
						cb = (ChoiceBox)scene.lookup("#choicebox");
						cb.getItems().addAll("None","BGM1","BGM2","BGM3");
						
						if(music=="")
							cb.setValue("BGM1");
						else 
							cb.setValue(music);	
						cb.setOnAction(new EventHandler<ActionEvent>() {
							@Override
							public void handle(ActionEvent event) {
								getChoice(cb);
							}
						});
						slider.setValue(volume);  			//�]�mslider���Ȭ�100
						
						volume_label.setText(""+(int)slider.getValue());
						slider.valueProperty().addListener(new ChangeListener<Number>() {
							public void changed(ObservableValue<? extends Number> ov,Number old_val, Number new_val ) {
								mediaplayer_BGM.setVolume(slider.getValue()/100);   //�վ㭵�q
								volume_label.setText(""+(int)slider.getValue());
								volume = mediaplayer_BGM.getVolume()*100;
							}
						});
						
						
						
					}catch(Exception ex) {
						
					}
			}
    	
    	});
    	bgm.setStyle("-fx-background-color: " + 
    			"        linear-gradient(#f2f2f2, #d6d6d6)," + 
    			"        linear-gradient(#fcfcfc 0%, #d9d9d9 20%, #d6d6d6 100%)," + 
    			"        linear-gradient(#dddddd 0%, #f6f6f6 50%);" + 
    			"    -fx-font-size: 16px;"+
    			"    -fx-background-radius: 8,7,6;" + 
    			"    -fx-background-insets: 0,1,2;" + 
    			"    -fx-text-fill: black;" + 
    			"    -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
    	pane.getChildren().remove(bgm);
    	pane.getChildren().add(bgm);
    }

    static boolean se_on=true;      		 //�O�_�}��SE
    static boolean se_first=true;            //�O�_�Ĥ@������SE
    
    public void Button_se() {                //����se
    	final Button se = new Button("  SE: ON  "); 
    	if(se_on==false)
    		se.setText("  SE:OFF  ");
    	se.setLayoutX(600);
    	se.setLayoutY(380);
    	se.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
		    	if(se_on==true)
		    		music_se("Click");
				if(se_first==true&&se_on==true) {
					se.setText("  SE:OFF  ");
					se_on=false;
					se_first=false;
				}
				else if(se_first==true&&se_on==false) {
					se.setText("  SE: ON  ");
					se_on=true;
					se_first=false;
				}
				else if(se_on==true) {
		    		se.setText("  SE:OFF  ");
		    		se_on=false;
				}
		    	else if(se_on==false) {
		    		se.setText("  SE: ON  ");
		    		se_on=true;
		    	}
				pane.requestFocus();
			}
    	});
    	se.setStyle("-fx-background-color: " + 
    			"        linear-gradient(#f2f2f2, #d6d6d6)," + 
    			"        linear-gradient(#fcfcfc 0%, #d9d9d9 20%, #d6d6d6 100%)," + 
    			"        linear-gradient(#dddddd 0%, #f6f6f6 50%);" + 
    			"    -fx-font-size: 16px;"+
    			"    -fx-background-radius: 8,7,6;" + 
    			"    -fx-background-insets: 0,1,2;" + 
    			"    -fx-text-fill: black;" + 
    			"    -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
    	pane.getChildren().remove(se);
    	pane.getChildren().add(se);
    }
    static int second=0;
	Label time_label = new Label();
	
    public void Time() {                     //�p��
    	TimerTask tt = new TimerTask() {
    		public void run() {
    			Platform.runLater(new Runnable() {        
    				public void run() {
    					time_label.setText("�ثe�ɶ�: "+String.format(" %02d:%02d:%02d", second/3600, second/60, second%60)); 
    					second++;
    				if(clear==true||turn_to_level==true) {      //�����ɰ���p��
    	    			cancel();
    	    			second--;
    				}
    				}
    			});
    		}
    	};
    	new Timer().scheduleAtFixedRate(tt, 0, 1000);  //1000ms =1s     //���e;�h�[�����Ĥ@��;���j�h�[����U�@��
    	time_label.setLayoutX(50);
    	time_label.setLayoutY(590);
    	time_label.setStyle("-fx-background-color: " + 
    			"        linear-gradient(#686868 0%, #232723 25%, #373837 75%, #757575 100%)," + 
    			"        linear-gradient(#020b02, #3a3a3a)," + 
    			"        linear-gradient(#b9b9b9 0%, #c2c2c2 20%, #afafaf 80%, #c8c8c8 100%)," + 
    			"        linear-gradient(#f5f5f5 0%, #dbdbdb 50%, #cacaca 51%, #d7d7d7 100%);" + 
    			"    -fx-background-insets: 0,1,4,5;" + 
    			"    -fx-background-radius: 9,8,5,4;" + 
    			"    -fx-padding: 15 30 15 30;" + 
    			"    -fx-font-family: \"Helvetica\";" + 
    			"    -fx-font-size: 18px;" + 
    			"    -fx-font-weight: bold;" + 
    			"    -fx-text-fill: #333333;" + 
    			"    -fx-effect: dropshadow( three-pass-box , rgba(255,255,255,0.2) , 1, 0.0 , 0 , 1);");

    }
    static int step=0;        //�B��
    int temp_pos_x;           //�e�@�B����m
    int temp_pos_y;          
    boolean first=true;
    Label step_label = new Label();
    
    public void Step() {                     //�p�B
    	if(first==true) {                     //Ū����l��m(��0�B)
    		temp_pos_x=map.char_data_x[level]; 
    		temp_pos_y=map.char_data_y[level];
    		first=false;
    	}
    	if((char_x!=temp_pos_x)||(char_y!=temp_pos_y))
    	{
    		temp_pos_x=char_x;         //�N�ثe��m����temp_pos_xy
    		temp_pos_y=char_y;
    		step++;
    	}
    	step_label.setLayoutX(320);
    	step_label.setLayoutY(590);
    	step_label.setStyle("-fx-background-color: " + 
    			"        linear-gradient(#686868 0%, #232723 25%, #373837 75%, #757575 100%)," + 
    			"        linear-gradient(#020b02, #3a3a3a)," + 
    			"        linear-gradient(#b9b9b9 0%, #c2c2c2 20%, #afafaf 80%, #c8c8c8 100%)," + 
    			"        linear-gradient(#f5f5f5 0%, #dbdbdb 50%, #cacaca 51%, #d7d7d7 100%);" + 
    			"    -fx-background-insets: 0,1,4,5;" + 
    			"    -fx-background-radius: 9,8,5,4;" + 
    			"    -fx-padding: 15 30 15 30;" + 
    			"    -fx-font-family: \"Helvetica\";" + 
    			"    -fx-font-size: 18px;" + 
    			"    -fx-font-weight: bold;" + 
    			"    -fx-text-fill: #333333;" + 
    			"    -fx-effect: dropshadow( three-pass-box , rgba(255,255,255,0.2) , 1, 0.0 , 0 , 1);");
    	step_label.setText("�B��:"+step);
    	record();
    }
    
    Label level_label = new Label();
    public void Level() {
    	level_label.setLayoutX(480);
    	level_label.setLayoutY(590);
    	level_label.setStyle("-fx-background-color: " + 
    			"        linear-gradient(#686868 0%, #232723 25%, #373837 75%, #757575 100%)," + 
    			"        linear-gradient(#020b02, #3a3a3a)," + 
    			"        linear-gradient(#b9b9b9 0%, #c2c2c2 20%, #afafaf 80%, #c8c8c8 100%)," + 
    			"        linear-gradient(#f5f5f5 0%, #dbdbdb 50%, #cacaca 51%, #d7d7d7 100%);" + 
    			"    -fx-background-insets: 0,1,4,5;" + 
    			"    -fx-background-radius: 9,8,5,4;" + 
    			"    -fx-padding: 15 30 15 30;" + 
    			"    -fx-font-family: \"Helvetica\";" + 
    			"    -fx-font-size: 18px;" + 
    			"    -fx-font-weight: bold;" + 
    			"    -fx-text-fill: #333333;" + 
    			"    -fx-effect: dropshadow( three-pass-box , rgba(255,255,255,0.2) , 1, 0.0 , 0 , 1);");
    	level_label.setText("Level "+(level+1));
    }
    //�ϥ�ArrayList�i�ۥѼW��e
    ArrayList<Integer> char_record = new ArrayList<Integer>();  //�����H���C��������
    ArrayList<Integer> box_record = new ArrayList<Integer>();//�����c�l�C������m
    
    public void record() {
    	char_record.add(step*2,char_x);
    	char_record.add(step*2+1,char_y);
    	for(int i=0;i<box_x.length;i++) {
    		box_record.add(step*(box_x.length)*2+i*2,box_x[i]);
    		box_record.add(step*(box_y.length)*2+i*2+1,box_y[i]);
    	}
    }
    public void back() {
    	char_record.remove(step*2);      //�����ثe��m������
    	char_record.remove(step*2+1);
    	for(int i=0;i<box_x.length;i++) {         
    		box_record.remove(step*(box_x.length)*2+i*2);
    		box_record.remove(step*(box_y.length)*2+i*2+1);
    	}
    	step--;
    	
    	char_x=char_record.get(step*2);  //Ū���W�@�Ӧ�m
    	char_y=char_record.get(step*2+1);
    	temp_pos_x=char_x;
    	temp_pos_y=char_y;
    	for(int i=0;i<box_x.length;i++) {
    		box_x[i]=box_record.get(step*(box_x.length)*2+i*2);
    		box_y[i]=box_record.get(step*(box_y.length)*2+i*2+1);
    	}
    	
    	imv_char.setLayoutX(char_x*48);
    	imv_char.setLayoutY(char_y*48);
    	for(int i=0;i<box_x.length;i++) {
			box_imv.get(i).setLayoutX(box_x[i]*48+8);        //��m�ݥ[8   ��]����
			box_imv.get(i).setLayoutY(box_y[i]*48+8);
        }
    	step_label.setText("�B��:"+step);
    }
    Media sound_BGM_1 = new Media(getClass().getResource("hitoriame.mp3").toExternalForm());
    Media sound_BGM_2 = new Media(getClass().getResource("mati.mp3").toExternalForm());
    Media sound_BGM_3 = new Media(getClass().getResource("bamboo_forest.mp3").toExternalForm());
    MediaPlayer mediaplayer_BGM = new MediaPlayer(sound_BGM_1);
	MediaView mediaview_BGM = new MediaView(mediaplayer_BGM);
	
    public void music_bgm()
    {	
 
    		switch(music) {
    			case "BGM1":
    				mediaplayer_BGM = new MediaPlayer(sound_BGM_1);
    				break;
    			case "BGM2":
    				mediaplayer_BGM = new MediaPlayer(sound_BGM_2);
    				break;
    			case "BGM3":
    				mediaplayer_BGM = new MediaPlayer(sound_BGM_3);
    				break;
    		}
    		mediaplayer_BGM.setOnEndOfMedia(new Runnable() {
        		public void run() {
        			mediaplayer_BGM.seek(Duration.ZERO);
        		}
        	});
    		mediaplayer_BGM.setVolume(volume/100);
    		pane.getChildren().remove(mediaview_BGM);
    		pane.getChildren().add(mediaview_BGM);    	
    		mediaplayer_BGM.play();
    }
    Media sound_SE_Clear = new Media(this.getClass().getResource("SE_Clear.mp3").toExternalForm());  //�q��SE
	MediaPlayer mediaplayer_SE_Clear = new MediaPlayer(sound_SE_Clear);
	
	Media sound_SE_Move = new Media(this.getClass().getResource("Movement.wav").toExternalForm());   //����SE
	MediaPlayer mediaplayer_SE_Move = new MediaPlayer(sound_SE_Move);
	
	Media sound_SE_Click = new Media(this.getClass().getResource("Button.wav").toExternalForm());    //�I��SE
	MediaPlayer mediaplayer_SE_Click = new MediaPlayer(sound_SE_Click);
	
	Media sound_SE_Bomb = new Media(this.getClass().getResource("Explosion.mp3").toExternalForm());    //�I��SE
	MediaPlayer mediaplayer_SE_Bomb = new MediaPlayer(sound_SE_Bomb);
	
	public void music_se(String type)
	{
		if(type=="Clear") {
			mediaplayer_SE_Clear.play();
			mediaplayer_SE_Clear.setOnEndOfMedia(new Runnable() {
	    		public void run() {
	    			mediaplayer_SE_Clear.stop();
	    		}
			});
		}
		else if(type=="Move") {
			mediaplayer_SE_Move.play();
			mediaplayer_SE_Move.setOnEndOfMedia(new Runnable() {
	    		public void run() {
	    			mediaplayer_SE_Move.stop();
	    		}
			});
		}
		else if(type=="Click") {
			mediaplayer_SE_Click.play();
			mediaplayer_SE_Click.setOnEndOfMedia(new Runnable() {
	    		public void run() {
	    			mediaplayer_SE_Click.stop();
	    		}
			});
		}
		else if(type=="Bomb") {
			mediaplayer_SE_Bomb.play();
			mediaplayer_SE_Bomb.setOnEndOfMedia(new Runnable() {
	    		public void run() {
	    			mediaplayer_SE_Bomb.stop();
	    		}
			});
		}
	}
	static boolean bomb_open = true;      //�O�_�}�Ҭ��u�\��
	static ImageView bomb_imv = new ImageView();
	public void Bomb() {
		Circle circle = new Circle();
		circle.setCenterX(655);
		circle.setCenterY(500);
		circle.setRadius(60);
		circle.setFill(Color.CORAL);
		pane.getChildren().add(circle);
		
		Image bomb_img = new Image(imgbox[5]);
		bomb_imv = new ImageView(bomb_img);
		bomb_imv.setLayoutX(635);
		bomb_imv.setLayoutY(475);
		bomb_imv.setMouseTransparent(true);
		pane.getChildren().add(bomb_imv);
		
		if(level<=3)
			bomb_imv.setOpacity(0.2);
		else
			new Help(level);
		circle.setOnMouseClicked(new EventHandler<Event>() {
			@Override
			public void handle(Event event) {
				if(bomb_open==true&&level>3) {
					new Help();
				}
			}
		});
		
	}
	static int bomb_x,bomb_y;
	public void Destroy() {                //�}�a����
		if(state=="UP") {
			if(map1[level][char_y-1][char_x]==3) {
				img = new Image(imgbox[2]);
				imv.get(char_x+(char_y-1)*12).setImage(img);
				bomb_x=char_x;
				bomb_y=char_y-1;
				bomb_open=false;
				bomb_imv.setOpacity(0.2);
				music_se("Bomb");
			}
		}
		else if(state=="DOWN") {
			if(map1[level][char_y+1][char_x]==3) {
				img = new Image(imgbox[2]);
				imv.get(char_x+(char_y+1)*12).setImage(img);
				bomb_x=char_x;
				bomb_y=char_y+1;
				bomb_open=false;
				bomb_imv.setOpacity(0.2);
				music_se("Bomb");
			}
		}
		else if(state=="LEFT") {
			if(map1[level][char_y][char_x-1]==3) {
				img = new Image(imgbox[2]);
				imv.get(char_x-1+char_y*12).setImage(img);
				bomb_x=char_x-1;
				bomb_y=char_y;
				bomb_open=false;
				bomb_imv.setOpacity(0.2);
				music_se("Bomb");
			}
		}
		else if(state=="RIGHT") {
			if(map1[level][char_y][(char_x)+1]==3) {
				
				img = new Image(imgbox[2]);
				imv.get(char_x+1+char_y*12).setImage(img);
				bomb_x=char_x+1;
				bomb_y=char_y;
				bomb_open=false;
				bomb_imv.setOpacity(0.2);
				music_se("Bomb");
			}
		}
		
	}
	public void Destroyed_Object_Recover() {        //��_�Q�}�a������
		imv.get(bomb_x+bomb_y*12).setImage(new Image(imgbox[3]));
	}
	static String music="";
	public void getChoice(ChoiceBox<String>cb ) {
		music = cb.getValue();
		switch(music) {
			case "None":
				mediaplayer_BGM.stop();
				break;
			case "BGM1":
				mediaplayer_BGM.stop();
				mediaplayer_BGM = new MediaPlayer(sound_BGM_1);
				mediaplayer_BGM.play();
				break;
			case "BGM2":
				mediaplayer_BGM.stop();
				mediaplayer_BGM = new MediaPlayer(sound_BGM_2);
				mediaplayer_BGM.play();
				break;
			case "BGM3":
				mediaplayer_BGM.stop();
				mediaplayer_BGM = new MediaPlayer(sound_BGM_3);
				mediaplayer_BGM.play();
				break;
		}
		mediaplayer_BGM.setVolume(volume/100);
		mediaplayer_BGM.setOnEndOfMedia(new Runnable() {
    		public void run() {
    			mediaplayer_BGM.seek(Duration.ZERO);
    		}
		});
	}
  

}

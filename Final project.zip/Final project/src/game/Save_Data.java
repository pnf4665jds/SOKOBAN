package game;

import java.io.Serializable;
import java.util.ArrayList;

public class Save_Data implements Serializable{
	static final long serialVersionUID = 1L;
	public int time1,step1;
	public int time2,step2;
	public int time3,step3;
	public int time4,step4;
	public int time5,step5;
}

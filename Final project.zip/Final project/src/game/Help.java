package game;


import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.animation.*;

public class Help {
	private String[] imgbox = new String[]{
			"/game/char48p.png",  
			"/game/box48p.png",
			"/game/floor48p.png",
			"/game/wall48p.png",
			"/game/target48p.png"
	};	
	Pane pane = new Pane();
	Parent root = pane;
	ImageView imv_char = new ImageView();
	Animation move_right,char_stop_right;
	Game_System gs = new Game_System();
	boolean se_on;
	public Help(boolean b)
	{
		Stage s = new Stage();
		Scene scene = new Scene(root,422,450);
		s.setTitle("SOKOBAN");                     
		s.setScene(scene);         
		Image application = new Image(imgbox[1]);
		s.getIcons().add(application);
		s.setResizable(false);                    
		s.show();                
		pane.setStyle("-fx-background-color: #f4a460");
		
		Button close= new Button("Close");
        close.setLayoutX(180);                                      
        close.setLayoutY(400);         
        close.setStyle("-fx-background-color: " + 
    			"        linear-gradient(#f2f2f2, #d6d6d6)," + 
    			"        linear-gradient(#fcfcfc 0%, #d9d9d9 20%, #d6d6d6 100%)," + 
    			"        linear-gradient(#dddddd 0%, #f6f6f6 50%);" + 
    			"    -fx-font-size: 16px;"+
    			"    -fx-background-radius: 8,7,6;" + 
    			"    -fx-background-insets: 0,1,2;" + 
    			"    -fx-text-fill: black;" + 
    			"    -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
        pane.getChildren().add(close);
        
        this.se_on=b;
		close.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				if(se_on==true) {
					gs.mediaplayer_SE_Click.stop();
					gs.mediaplayer_SE_Click.play();
				}
				Stage currentStage = (Stage)pane.getScene().getWindow();
				currentStage.close();                                    //����������
	        }
	    });
		Label label = new Label();
		label.setText("How  to  play :\n\nUse  UP ,DOWN, RIGHT ,LEFT  to  push  \n\n                                  to\n\n");
		label.setLayoutX(20);
		label.setLayoutY(180);
		label.setStyle("-fx-background-color:" + 
				"        #ecebe9," + 
				"        rgba(0,0,0,0.05)," + 
				"        linear-gradient(#dcca8a, #c7a740)," + 
				"        linear-gradient(#f9f2d6 0%, #f4e5bc 20%, #e6c75d 80%, #e2c045 100%)," + 
				"        linear-gradient(#f6ebbe, #e6c34d);" + 
				"    -fx-background-insets: 0,9 9 8 9,9,10,11;" + 
				"    -fx-background-radius: 50;" + 
				"    -fx-padding: 15 30 15 30;" + 
				"    -fx-font-family: \"Helvetica\";" + 
				"    -fx-font-size: 18px;" + 
				"    -fx-text-fill: #311c09;" + 
				"    -fx-effect: innershadow( three-pass-box , rgba(0,0,0,0.1) , 2, 0.0 , 0 , 1);");
		pane.getChildren().add(label);
		
		BackgroundInitialize();
		move_right = new SpriteAnimation(imv_char,Duration.millis(500),3,3,0,96,48,48);
		char_stop_right = new SpriteAnimation(imv_char,Duration.millis(500),1,1,48,96,48,48);
		Animation();
	}
	Stage s;
	public Help(int a) {
		s = new Stage();
		Scene scene = new Scene(root,372,200);
		s.setTitle("SOKOBAN");                     
		s.setScene(scene);         
		Image application = new Image(imgbox[1]);
		s.getIcons().add(application);
		s.setResizable(false);                    
		s.show();                
		pane.setStyle("-fx-background-color: #f4a460");
		
		Label warning = new Label();
		warning.setLayoutX(30);
		warning.setLayoutY(20);
		warning.setText("               In  this  level             \n\n     you  can  use  the  Bomb!      ");
		warning.setStyle("-fx-background-color:" + 
				"        #ecebe9," + 
				"        rgba(0,0,0,0.05)," + 
				"        linear-gradient(#dcca8a, #c7a740)," + 
				"        linear-gradient(#f9f2d6 0%, #f4e5bc 20%, #e6c75d 80%, #e2c045 100%)," + 
				"        linear-gradient(#f6ebbe, #e6c34d);" + 
				"    -fx-background-insets: 0,9 9 8 9,9,10,11;" + 
				"    -fx-background-radius: 50;" + 
				"    -fx-padding: 15 30 15 30;" + 
				"    -fx-font-family: \"Helvetica\";" + 
				"    -fx-font-size: 18px;" + 
				"    -fx-text-fill: #311c09;" + 
				"    -fx-effect: innershadow( three-pass-box , rgba(0,0,0,0.1) , 2, 0.0 , 0 , 1);");
		pane.getChildren().add(warning);
		
		Button ok= new Button("OK");
        ok.setLayoutX(156);                                      
        ok.setLayoutY(150);         
        ok.setStyle("-fx-background-color: " + 
    			"        linear-gradient(#f2f2f2, #d6d6d6)," + 
    			"        linear-gradient(#fcfcfc 0%, #d9d9d9 20%, #d6d6d6 100%)," + 
    			"        linear-gradient(#dddddd 0%, #f6f6f6 50%);" + 
    			"    -fx-font-size: 16px;"+
    			"    -fx-background-radius: 8,7,6;" + 
    			"    -fx-background-insets: 0,1,2;" + 
    			"    -fx-text-fill: black;" + 
    			"    -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
        pane.getChildren().add(ok);
        
        ok.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				s.close();
			}
		});
	}
	public Help() {                        //�ϥά��uĵ�i
		Stage s = new Stage();
		Scene scene = new Scene(root,422,250);
		s.setTitle("SOKOBAN");                     
		s.setScene(scene);         
		Image application = new Image(imgbox[1]);
		s.getIcons().add(application);
		s.setResizable(false);                    
		s.show();                
		pane.setStyle("-fx-background-color: #f4a460");
		
		Label warning = new Label();
		warning.setLayoutX(30);
		warning.setLayoutY(20);
		warning.setText("      You  only  have  one  Bomb      \n\n      Do  you  want  to  use  Bomb?      \n\n It  will  destroy  the  wall  you  face\n\n");
		warning.setStyle("-fx-background-color:" + 
				"        #ecebe9," + 
				"        rgba(0,0,0,0.05)," + 
				"        linear-gradient(#dcca8a, #c7a740)," + 
				"        linear-gradient(#f9f2d6 0%, #f4e5bc 20%, #e6c75d 80%, #e2c045 100%)," + 
				"        linear-gradient(#f6ebbe, #e6c34d);" + 
				"    -fx-background-insets: 0,9 9 8 9,9,10,11;" + 
				"    -fx-background-radius: 50;" + 
				"    -fx-padding: 15 30 15 30;" + 
				"    -fx-font-family: \"Helvetica\";" + 
				"    -fx-font-size: 18px;" + 
				"    -fx-text-fill: #311c09;" + 
				"    -fx-effect: innershadow( three-pass-box , rgba(0,0,0,0.1) , 2, 0.0 , 0 , 1);");
		pane.getChildren().add(warning);
		
		Button tobomb= new Button("Yes");
        tobomb.setLayoutX(90);                                      
        tobomb.setLayoutY(200);         
        tobomb.setStyle("-fx-background-color: " + 
    			"        linear-gradient(#f2f2f2, #d6d6d6)," + 
    			"        linear-gradient(#fcfcfc 0%, #d9d9d9 20%, #d6d6d6 100%)," + 
    			"        linear-gradient(#dddddd 0%, #f6f6f6 50%);" + 
    			"    -fx-font-size: 16px;"+
    			"    -fx-background-radius: 8,7,6;" + 
    			"    -fx-background-insets: 0,1,2;" + 
    			"    -fx-text-fill: black;" + 
    			"    -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
        pane.getChildren().add(tobomb);
        
        Button notobomb= new Button("No");
        notobomb.setLayoutX(270);                                      
        notobomb.setLayoutY(200);         
        notobomb.setStyle("-fx-background-color: " + 
    			"        linear-gradient(#f2f2f2, #d6d6d6)," + 
    			"        linear-gradient(#fcfcfc 0%, #d9d9d9 20%, #d6d6d6 100%)," + 
    			"        linear-gradient(#dddddd 0%, #f6f6f6 50%);" + 
    			"    -fx-font-size: 16px;"+
    			"    -fx-background-radius: 8,7,6;" + 
    			"    -fx-background-insets: 0,1,2;" + 
    			"    -fx-text-fill: black;" + 
    			"    -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
        pane.getChildren().add(notobomb);
        
        tobomb.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Game_System gs = new Game_System();
				gs.Destroy();
				Stage currentStage = (Stage)pane.getScene().getWindow();
				currentStage.close();                                    //����������
	        }
	    });
        
        notobomb.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Stage currentStage = (Stage)pane.getScene().getWindow();
				currentStage.close();                                    //����������
	        }
	    });
	}
	int mapData[][] = {{3,3,3,3,3,3,3,3,3},
					   {3,2,2,2,2,2,2,4,3},
					   {3,3,3,3,3,3,3,3,3}};
	int char_x=1;
	int box_x=2;

	private void Animation() {
		Image img_char = new Image("/game/move_character.png");
		imv_char.setImage(img_char);
		pane.getChildren().add(imv_char);
		imgb = new Image(imgbox[1]);
		final ImageView ivb = new ImageView(imgb);
		pane.getChildren().add(ivb);
		
		TimerTask tt = new TimerTask() {
    		public void run() {
    			Platform.runLater(new Runnable() {        
    				public void run() {
    					imv_char.setLayoutX(char_x*48);
    					imv_char.setLayoutY(48);
    					move_right.play();
    	            	
                		move_right.setOnFinished(new EventHandler<ActionEvent>() {
    						
    						@Override
    						public void handle(ActionEvent arg0) {
    							// TODO Auto-generated method stub
    							char_stop_right.play();
    						}
    					});
    					char_x++;
    					
    					ivb.setLayoutX(char_x*48+8);
    					ivb.setLayoutY(56);
    					box_x++;
    					
    					if(char_x==7) {
    						char_x=1;
    						box_x=2;
    					}
    				}
    			});
    		}
    	};
    	new Timer().scheduleAtFixedRate(tt, 0, 800);  //1000ms =1s     //���e;�h�[�����Ĥ@��;���j�h�[����U�@��
	}
	private Image img,imgb;
	ArrayList <ImageView> imv = new ArrayList<ImageView>();     //imageView with ArrayList
	public void BackgroundInitialize() {
		for(int i=0 ;i<3 ;i++) {
			for(int j=0 ; j<9 ;j++)
			{
				if(mapData[i][j]==2) {
				    img = new Image(imgbox[2]);
				}
				else if(mapData[i][j]==3)
					img = new Image(imgbox[3]);
				else if(mapData[i][j]==4)
					img = new Image(imgbox[4]);
				
				ImageView iv= new ImageView();
				iv.setImage(img);
				iv.setLayoutX(j*48);
				iv.setLayoutY(i*48);
				imv.add(iv);
			}
		}
		ImageView iv= new ImageView();
		iv.setImage(new Image(imgbox[4]));
		iv.setLayoutX(244);
		iv.setLayoutY(285);
		imv.add(iv);
		ImageView ivb= new ImageView();
		ivb.setImage(new Image(imgbox[1]));
		ivb.setLayoutX(148);
		ivb.setLayoutY(300);
		imv.add(ivb);
		pane.getChildren().addAll(imv);        //�ϥ�arraylist�~��N�C��image�L�X
		
	}
}

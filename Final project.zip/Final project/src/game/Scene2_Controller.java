package game;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;


import javafx.animation.PathTransition;
import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;
import game.Game_System;

public class Scene2_Controller implements Initializable{
	Game_System gs = new Game_System();
	static int level=0;
	@FXML
	private StackPane stackpane;
	
	@FXML
	private void Level1_Button(ActionEvent e) {
		level=0;
		SceneTransitionIn();
	}
	
	@FXML
	private void Level2_Button(ActionEvent e) {
		level=1;
		SceneTransitionIn();
	}
	
	@FXML
	private void Level3_Button(ActionEvent e) {
		level=2;
		SceneTransitionIn();
	}
	
	@FXML
	private void Level4_Button(ActionEvent e) {
		level=3;
		SceneTransitionIn();
	}
	
	@FXML
	private void Level5_Button(ActionEvent e) {
		level=4;
		SceneTransitionIn();
	}
	
	@FXML
	private void Level6_Button(ActionEvent e) {
		level=5;
		SceneTransitionIn();
	}
	
	@FXML
	private void Home_Button(ActionEvent e) {
		final Rectangle rect = new Rectangle(1200,700);        //(x,y,�e,��)
		rect.setFill(Color.BLACK);
		
		Line line = new Line();
	    line.setStartX(1600);
	    line.setStartY(350);
		line.setEndX(-400);
		line.setEndY(350);
		
		PathTransition pt = new PathTransition();
		pt.setDuration(Duration.seconds(2.75));
		pt.setPath(line);
		pt.setNode(rect);
		pt.play();
		
		stackpane.getChildren().add(rect);
		
		TimerTask tt = new TimerTask() {
    		public void run() {
    			Platform.runLater(new Runnable() {        
    				public void run() {
    					try {
    						StackPane sp = FXMLLoader.load(getClass().getResource("/game/Scene1.fxml"));
    						stackpane.getChildren().add(sp);
    					} catch (IOException ex) {
    						// TODO Auto-generated catch block
    						ex.printStackTrace();
    					}
    				}
    			});
    		}
    	};
    	new Timer().schedule(tt,1200);
	}
	
	@Override
	public void initialize(URL location, ResourceBundle resource) {
		Game_System.second=0;          //��l�Ʈɶ��B�B��
		Game_System.step=0;
		SceneTransitionOut();
	}
	private void SceneTransitionIn() {
		final Rectangle rect = new Rectangle(1200,700);        //(x,y,�e,��)
		rect.setFill(Color.BLACK);
		
		Line line = new Line();
	    line.setStartX(1600);
	    line.setStartY(350);
		line.setEndX(-400);
		line.setEndY(350);
		
		PathTransition pt = new PathTransition();
		pt.setDuration(Duration.seconds(2.75));
		pt.setPath(line);
		pt.setNode(rect);
		pt.play();
		
		stackpane.getChildren().add(rect);
		
		TimerTask tt = new TimerTask() {
    		public void run() {
    			Platform.runLater(new Runnable() {        
    				public void run() {
    					Stage currentStage = (Stage)stackpane.getScene().getWindow();   //���o�ثe��stage
    					new Game_System(currentStage);
    					
    				}
    			});
    		}
    	};
    	new Timer().schedule(tt,1200);
	}
	private void SceneTransitionOut() {
		final Rectangle rect = new Rectangle(1200,700);        //(x,y,�e,��)
		rect.setFill(Color.BLACK);
		
		Line line = new Line();
	    line.setStartX(500);
	    line.setStartY(350);
		line.setEndX(-400);
		line.setEndY(350);
		
		PathTransition pt = new PathTransition();
		pt.setDuration(Duration.seconds(2.0));
		pt.setPath(line);
		pt.setNode(rect);
		pt.play();
		
		stackpane.getChildren().add(rect);
	}
/*	private void makeFadeOut() {
		FadeTransition ft = new FadeTransition(Duration.seconds(2),rootPane);
		ft.setFromValue(1);     //���z��1 >>> �z��0
		ft.setToValue(0);
		ft.setOnFinished(new EventHandler<ActionEvent>() {   //���ݰ��浲��
			@Override
			public void handle(ActionEvent event) {
				Stage currentStage = (Stage)rootPane.getScene().getWindow();   //���o�ثe��stage
				new Game_System(currentStage);
			}
		});
		ft.play();
	}*/
}

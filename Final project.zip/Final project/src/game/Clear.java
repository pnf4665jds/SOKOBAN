package game;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

import javafx.animation.FadeTransition;
import javafx.animation.PathTransition;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Clear{
	AnchorPane anchorpane = new AnchorPane();
	Parent root = anchorpane;
	StackPane sp = new StackPane();
	Record record;
	Clear(Stage s){
		Scene scene = new Scene(root,720,650);    //�]�m�����j�p
		s.setTitle("SOKOBAN");                     //���ε{���W��
		s.setScene(scene);                        //�]�m��������Stage
		Image application = new Image("/game/box48p.png");
		s.getIcons().add(application);
		s.setResizable(false);                    //������j������
		s.show();                                 //���Stage
		
		anchorpane.setOpacity(0);
		makeFadeIn();
		
		anchorpane.setStyle("-fx-background-color: #f4a460");
		
		Label clear = new Label("Level "+(Scene2_Controller.level+1)+" CLEAR!!!");
		anchorpane.setTopAnchor(clear, 50.0);
		anchorpane.setBottomAnchor(clear, 500.0);
		anchorpane.setLeftAnchor(clear, 50.0);
		anchorpane.setRightAnchor(clear, 50.0);
		clear.setAlignment(Pos.CENTER);
		anchorpane.getChildren().add(clear);
		clear.setStyle("-fx-background-color: " + 
    			"        linear-gradient(#686868 0%, #232723 25%, #373837 75%, #757575 100%)," + 
    			"        linear-gradient(#020b02, #3a3a3a)," + 
    			"        linear-gradient(#b9b9b9 0%, #c2c2c2 20%, #afafaf 80%, #c8c8c8 100%)," + 
    			"        linear-gradient(#f5f5f5 0%, #dbdbdb 50%, #cacaca 51%, #d7d7d7 100%);" + 
    			"    -fx-background-insets: 0,1,4,5;" + 
    			"    -fx-background-radius: 9,8,5,4;" + 
    			"    -fx-padding: 15 30 15 30;" + 
    			"    -fx-font-family: \"Helvetica\";" + 
    			"    -fx-font-size: 18px;" + 
    			"    -fx-font-weight: bold;" + 
    			"    -fx-text-fill: #333333;" + 
    			"    -fx-effect: dropshadow( three-pass-box , rgba(255,255,255,0.2) , 1, 0.0 , 0 , 1);");
		
		Label time = new Label();
		time.setText("�ɶ�: "+String.format(" %02d:%02d:%02d", Game_System.second/3600, Game_System.second/60, Game_System.second%60));
		anchorpane.setTopAnchor(time, 220.0);
		anchorpane.setBottomAnchor(time, 335.0);
		anchorpane.setLeftAnchor(time, 50.0);
		anchorpane.setRightAnchor(time, 50.0);
		time.setAlignment(Pos.CENTER);
		anchorpane.getChildren().add(time);
		time.setStyle("-fx-background-color: " + 
    			"        linear-gradient(#686868 0%, #232723 25%, #373837 75%, #757575 100%)," + 
    			"        linear-gradient(#020b02, #3a3a3a)," + 
    			"        linear-gradient(#b9b9b9 0%, #c2c2c2 20%, #afafaf 80%, #c8c8c8 100%)," + 
    			"        linear-gradient(#f5f5f5 0%, #dbdbdb 50%, #cacaca 51%, #d7d7d7 100%);" + 
    			"    -fx-background-insets: 0,1,4,5;" + 
    			"    -fx-background-radius: 9,8,5,4;" + 
    			"    -fx-padding: 15 30 15 30;" + 
    			"    -fx-font-family: \"Helvetica\";" + 
    			"    -fx-font-size: 18px;" + 
    			"    -fx-font-weight: bold;" + 
    			"    -fx-text-fill: #333333;" + 
    			"    -fx-effect: dropshadow( three-pass-box , rgba(255,255,255,0.2) , 1, 0.0 , 0 , 1);");
		
		Label step = new Label();
		step.setText("�B��:"+(Game_System.step));
		anchorpane.setTopAnchor(step, 390.0);
		anchorpane.setBottomAnchor(step, 160.0);
		anchorpane.setLeftAnchor(step, 50.0);
		anchorpane.setRightAnchor(step, 50.0);
		step.setAlignment(Pos.CENTER);
	    anchorpane.getChildren().add(step);
	    step.setStyle("-fx-background-color: " + 
    			"        linear-gradient(#686868 0%, #232723 25%, #373837 75%, #757575 100%)," + 
    			"        linear-gradient(#020b02, #3a3a3a)," + 
    			"        linear-gradient(#b9b9b9 0%, #c2c2c2 20%, #afafaf 80%, #c8c8c8 100%)," + 
    			"        linear-gradient(#f5f5f5 0%, #dbdbdb 50%, #cacaca 51%, #d7d7d7 100%);" + 
    			"    -fx-background-insets: 0,1,4,5;" + 
    			"    -fx-background-radius: 9,8,5,4;" + 
    			"    -fx-padding: 15 30 15 30;" + 
    			"    -fx-font-family: \"Helvetica\";" + 
    			"    -fx-font-size: 18px;" + 
    			"    -fx-font-weight: bold;" + 
    			"    -fx-text-fill: #333333;" + 
    			"    -fx-effect: dropshadow( three-pass-box , rgba(255,255,255,0.2) , 1, 0.0 , 0 , 1);");
		
		Button next= new Button("Next");
		anchorpane.setTopAnchor(next, 600.0);
		anchorpane.setBottomAnchor(next, 0.0);
		anchorpane.setLeftAnchor(next, 50.0);
		anchorpane.setRightAnchor(next, 50.0);
        anchorpane.getChildren().add(next);
        next.setStyle("-fx-background-color: " + 
    			"        linear-gradient(#f2f2f2, #d6d6d6)," + 
    			"        linear-gradient(#fcfcfc 0%, #d9d9d9 20%, #d6d6d6 100%)," + 
    			"        linear-gradient(#dddddd 0%, #f6f6f6 50%);" + 
    			"    -fx-font-size: 16px;"+
    			"    -fx-background-radius: 8,7,6;" + 
    			"    -fx-background-insets: 0,1,2;" + 
    			"    -fx-text-fill: black;" + 
    			"    -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
        
        
		next.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				SceneTransitionIn();
			}
    	});
	}
	public void loadNextScene() {
		Parent secondView;
		try {
			secondView = (StackPane)FXMLLoader.load(getClass().getResource("/game/Scene2.fxml"));
			anchorpane.getChildren().add(secondView);
			anchorpane.setTopAnchor(secondView, 0.0);
			anchorpane.setBottomAnchor(secondView, 0.0);
			anchorpane.setLeftAnchor(secondView, 0.0);
			anchorpane.setRightAnchor(secondView, 0.0);
			}
		catch(IOException e) {
			e.printStackTrace();
		}	
	}
	private void makeFadeIn() {
		FadeTransition ft = new FadeTransition(Duration.seconds(2),anchorpane);
		ft.setFromValue(0);     //���z��1 <<< �z��0
		ft.setToValue(1);
		ft.play();
	}
	private void SceneTransitionIn() {
		final Rectangle rect = new Rectangle(1200,700);        //(x,y,�e,��)
		rect.setFill(Color.BLACK);
		
		Line line = new Line();
	    line.setStartX(1600);
	    line.setStartY(350);
		line.setEndX(-400);
		line.setEndY(350);
		
		PathTransition pt = new PathTransition();
		pt.setDuration(Duration.seconds(2.75));
		pt.setPath(line);
		pt.setNode(rect);
		pt.play();
		
		anchorpane.getChildren().add(rect);
		
		TimerTask tt = new TimerTask() {
    		public void run() {
    			Platform.runLater(new Runnable() {        
    				public void run() {
    					loadNextScene();
    				}
    			});
    		}
    	};
    	new Timer().schedule(tt,1500);
	}
}
